$(document).ready(init);
function init()
{
    //Your Code Here !!
}