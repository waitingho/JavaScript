// JavaScript Document
var loadData="Global";
function loadFun(input)
{	
	var loadData="Local";
	return "loadData="+loadData+"<br> input="+input;
}
